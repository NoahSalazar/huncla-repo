<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('linkedinapi');
$autoload['drivers'] = array();
$autoload['helper'] = array("linkedin");
$autoload['config'] = array();
$autoload['language'] = array("linkedin");
$autoload['model'] = array();
